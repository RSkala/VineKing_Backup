This zip file is used by the Zip code unit tests. It was created in WinZip 11
and is used to ensure compatibility with existing zip applications.

