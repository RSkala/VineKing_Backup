$levelDatablocks = new SimSet() {
   canSaveDynamicFields = "1";
      setType = "Datablocks";

   new t2dImageMapDatablock(DebugMainMenuButtonsImageMap) {
      imageName = "~/data/images/DebugMainMenuButtons.png";
      imageMode = "CELL";
      frameCount = "-1";
      filterMode = "NONE";
      filterPad = "0";
      preferPerf = "1";
      cellRowOrder = "1";
      cellOffsetX = "0";
      cellOffsetY = "0";
      cellStrideX = "0";
      cellStrideY = "0";
      cellCountX = "-1";
      cellCountY = "-1";
      cellWidth = "128";
      cellHeight = "128";
      preload = "0";
      allowUnload = "0";
      compressPVR = "0";
      optimised = "0";
      force16bit = "0";
   };
	new t2dImageMapDatablock(mainmenu_cd_screenImageMap) {
		imageName = "~/data/images/mainmenu_cd_screen.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(mainmenu_op_screenImageMap) {
		imageName = "~/data/images/mainmenu_op_screen.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(mainmenu_title_screen_wordsImageMap) {
		imageName = "~/data/images/mainmenu_title_screen_words.png";
		imageMode = "CELL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "256";
		cellHeight = "32";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(buttons_newImageMap) {
		imageName = "~/data/images/buttons_new.png";
		imageMode = "CELL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "64";
		cellHeight = "64";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(yes_no_buttonsImageMap) {
		imageName = "~/data/images/yes_no_buttons.png";
		imageMode = "CELL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "128";
		cellHeight = "64";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(gamecenter_logoImageMap) {
		imageName = "~/data/images/gamecenter_logo.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(Achievement_BannerImageMap) {
		imageName = "~/data/images/Achievement_Banner.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(_4x4_White_SquareImageMap) {
		imageName = "~/data/images/4x4_White_Square.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(Menu_Back_GroundImageMap) {
		imageName = "~/data/images/Menu_Back_Ground.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(Menu_clouds_scrollersImageMap) {
		imageName = "~/data/images/Menu_clouds_scrollers.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(Menu_vine_king_eyesImageMap) {
		imageName = "~/data/images/Menu_vine_king_eyes.png";
		imageMode = "CELL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "1";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "16";
		cellHeight = "32";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(Menu_vine_king_vineImageMap) {
		imageName = "~/data/images/Menu_vine_king_vine.png";
		imageMode = "CELL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "128";
		cellHeight = "64";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(Menu_VineKing_textImageMap) {
		imageName = "~/data/images/Menu_VineKing_text.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dAnimationDatablock(Menu_vine_king_vineAnimation) {
		imageMap = "Menu_vine_king_vineImageMap";
		animationFrames = "0 1 2 3";
		animationTime = "0.5";
		animationCycle = "1";
		randomStart = "0";
		startframe = "0";
		pingPong = "0";
		playForward = "1";
	};
	new t2dImageMapDatablock(Menu_vine_king_eyesImageMap) {
		imageName = "~/data/images/Menu_vine_king_eyes.png";
		imageMode = "CELL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "16";
		cellHeight = "32";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dAnimationDatablock(VINEKING_EYE_SMALL) {
		imageMap = "Menu_vine_king_eyesImageMap";
		animationFrames = "2 2 2 2 2 2 0";
		animationTime = "3.5";
		animationCycle = "1";
		randomStart = "0";
		startframe = "0";
		pingPong = "0";
		playForward = "1";
	};
	new t2dAnimationDatablock(VINEKING_EYE_LARGE) {
		imageMap = "Menu_vine_king_eyesImageMap";
		animationFrames = "2 2 2 2 2 2 1";
		animationTime = "3.5";
		animationCycle = "1";
		randomStart = "0";
		startframe = "0";
		pingPong = "0";
		playForward = "1";
	};
	new t2dImageMapDatablock(Credits1ImageMap) {
		imageName = "~/data/images/Credits1.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	new t2dImageMapDatablock(corner_buttonImageMap) {
		imageName = "~/data/images/corner_button.png";
		imageMode = "FULL";
		frameCount = "-1";
		filterMode = "NONE";
		filterPad = "0";
		preferPerf = "1";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = "0";
		cellHeight = "0";
		preload = "0";
		allowUnload = "0";
		compressPVR = "0";
		optimised = "0";
		force16bit = "0";
	};
	//================================================================================================
	// Audio Descriptions
	//================================================================================================
	
	new AudioDescription( AudioLooping )  
	{  
		volume = 1.0;
		isLooping = true;
		is3D = false;
		type = 1;
		isStreaming = false;
	}; 
	
	new AudioDescription( AudioBGMNonLooping )  
	{  
		volume = 1.0;
		isLooping = false;
		is3D = false;
		type = 2;
		isStreaming = false;
	};
	
	new AudioDescription( AudioNonLooping )
	{
		volume = 1.0;
		isLooping = false;
		is3D = false;
		type = 3;
		isStreaming = false;
	};
	
	//-----------------------------------------------------------
	new AudioProfile( BGM_MainMenuRPG )
	{
		filename = "~/data/audio/P02_BGM_Main_Menu.wav";
		description = "AudioLooping";
		preload = false;
	};
	
	new AudioProfile( ButtonClickBack )
	{
		filename = "~/data/audio/P02_SFX_Click_B.wav";
		description = "AudioNonLooping";
		preload = false;
	};
	
	new AudioProfile( ButtonClickForward )
	{
		filename = "~/data/audio/P02_SFX_Click_F.wav";
		description = "AudioNonLooping";
		preload = false;
	};
	new AudioProfile( PlayerDeath )
	{
		filename = "~/data/audio/P02_SFX_Player_Death.wav";
		description = "AudioNonLooping";
		preload = false;
	};
};
