$persistentObjectSet = new SimSet() {
   canSaveDynamicFields = "1";
      setType = "Persistent";

   new t2dStaticSprite(NodeReferenceGrid) {
      imageMap = "P0_02_GRID_NUMBERSImageMap";
      frame = "0";
      mUseSourceRect = "0";
      sourceRect = "0 0 0 0";
      canSaveDynamicFields = "1";
      Position = "-742.285 -444.563";
      size = "320.000 480.000";
      Layer = "3";
      CollisionPhysicsSend = "0";
      CollisionPhysicsReceive = "0";
      CollisionMaxIterations = "3";
   };
};
